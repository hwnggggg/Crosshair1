using Microsoft.Gaming.XboxGameBar;
using System;
using Windows.Foundation;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace WidgetForegroundWorkerSample
{
    public sealed partial class Widget1 : Page
    {
        private XboxGameBarWidget widget;

        public Widget1()
        {
            InitializeComponent();
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            widget = e.Parameter as XboxGameBarWidget;
            if (widget == null)
            {
                return;
            }

            widget.HorizontalResizeSupported = false;
            widget.VerticalResizeSupported = false;
            widget.PinningSupported = true;
            widget.MinWindowSize = new Size(64, 64);
            widget.MaxWindowSize = new Size(64, 64);

            await widget.TryResizeWindowAsync(new Size(64, 64));
            await widget.CenterWindowAsync();
        }
    }
}
