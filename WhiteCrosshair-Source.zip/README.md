# White Crosshair — Xbox Game Bar widget

This project draws a white crosshair through the official Xbox Game Bar widget system.

## Build online without Visual Studio

Open the repository's **Actions** tab, choose **Build installable crosshair**, and click
**Run workflow**. When it finishes, download the **WhiteCrosshair-Installer** artifact
and follow `INSTALL.txt` inside it.

Crosshair settings:

- Color: white
- Arm length: 2 epx
- Thickness: 2 epx
- Gap: 0
- Center dot: none

## Requirements

- Windows 10 or Windows 11
- Xbox Game Bar installed and updated
- Visual Studio 2022 Community
- In Visual Studio Installer, enable **Universal Windows Platform development** and a Windows 10/11 SDK
- Windows Developer Mode enabled under **Settings > Privacy & security > For developers**

## Install locally

1. Open `WhiteCrosshair.sln` in Visual Studio 2022.
2. If Visual Studio asks to retarget the Windows SDK, accept the installed version.
3. Select `Debug` and `x64` in the top toolbar.
4. Select **Build > Deploy Solution**.
5. Open a compatible game and press `Win + G`.
6. Open the **Widget Menu**, then choose **White Crosshair**.
7. Press the widget's **Pin** button.
8. Close Game Bar. The title bar disappears and the centered crosshair remains.

If the game changes resolution or the crosshair is displaced, close and reopen the widget so it centers again.

## Edit the shape

The visible shape is in `Widget1.xaml`. The horizontal rectangle is `4 x 2` epx and the vertical rectangle is `2 x 4` epx, producing two-pixel arms with no gap.

## Compatibility

Game Bar works with many DirectX fullscreen games. Microsoft documents limitations for some Vulkan and OpenGL exclusive-fullscreen games. Always follow the rules of the game being played.

## Attribution

The Game Bar activation and packaging scaffold is adapted from Microsoft's Xbox Game Bar SDK samples. Microsoft's original license is included as `LICENSE-Microsoft.txt`.
